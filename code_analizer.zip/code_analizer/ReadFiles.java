import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;



public class ReadFiles {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> results = new ArrayList<String>();


		File[] files = new File("C:\\test\\acurity\\reports\\").listFiles();
		//If this pathname does not denote a directory, then listFiles() returns null. 

		for (File file : files) {
		    if (file.isFile()) {
		        results.add(file.getAbsolutePath());
		    }
		}
		Analyser Liner = new Analyser();
		List<String> content = new ArrayList<String>();
		List<Function> listfunctionscalls = new ArrayList<Function>();
		List<Function> listfunctiondefinition = new ArrayList<Function>();
		List<Variable> listvariables = new ArrayList<Variable>();
		try {
			
				for (int i = 0; i < results.size(); i++) {
						content = Liner.GetLines(results.get(i));
						//if (results.get(i).indexOf("U8M8") > 0)
							Liner.GetFunctions(content,listfunctionscalls,listfunctiondefinition,listvariables,results.get(i));
					}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		GetParametersAndTypesInFunctionDefinition(listfunctiondefinition);
		CompareParametersInFunctionCallsWithParametersInFunctionDefinition(listfunctionscalls,listfunctiondefinition);
		
		
		saveResults(listfunctionscalls,"C:\\test\\acurity\\function_calls.txt");
		saveResults(listfunctiondefinition,"C:\\test\\acurity\\function_definition.txt");
		saveVariable(listvariables,"C:\\test\\acurity\\variables_definition.txt");

	}

	private static void GetParametersAndTypesInFunctionDefinition(
			List<Function> listfunctiondefinition) {
		// TODO Auto-generated method stub
		String functiondef = "";
		String functionName = "";
		String[] FunctionParameters = new String[]{};
		String[] parameter = new String[] {};
		String[] Parameters = null;
		String[] Types = new String[] {};
		int positionParent1;
		int positionParent2;
		Function myfunction = new Function();
		for(int i=0;i< listfunctiondefinition.size();i++)
		{
			myfunction = listfunctiondefinition.get(i);
			functiondef = myfunction.FuntionName;
			functiondef = functiondef.replaceFirst("FUNCTION","");
			positionParent1 = functiondef.indexOf("(");
			functionName = functiondef.substring(0, positionParent1);
			positionParent2 = functiondef.indexOf(")");
			FunctionParameters = new String[]{};
		//	Parameters = null;
		//Types = new String[] {};
		
			
			if (functiondef.indexOf(",") > 0)
			{
			FunctionParameters = functiondef.substring(positionParent1+1, positionParent2).split(",");
			Parameters = new String[FunctionParameters.length];
			Types = new String[FunctionParameters.length];
			for(int j=0;j<FunctionParameters.length;j++)
			{
				parameter = new String[] {};
				parameter = FunctionParameters[j].split(":");
				if (parameter.length == 2)
				{
				Parameters[j] = parameter[0];
				Types[j] = parameter[1];
				}
				//else
					//System.out.println("Error extracting parameters" + FunctionParameters[j] + myfunction + "FileName " + myfunction.FuntionName);
			}
			}
			else
			{	Parameters = new String[1];
			Types = new String[1];
				if ((positionParent2 - positionParent1) ==1)
				{
			
				Parameters[0] = "";
				Types[0] = "";
				}
				else
				{
					FunctionParameters = functiondef.substring(positionParent1+1, positionParent2).split(":");
					if (FunctionParameters.length == 2)
					{
					Parameters[0] = FunctionParameters[0];
					Types[0] = FunctionParameters[1];
					}
					//else
					//{
					//	System.out.println("Error finding parameters in " + functiondef + "in file : "   + myfunction.FileName + " " + myfunction.FuntionName); 
					//}
				}
			}
			
			myfunction.FunctionNameShort = functionName;
			myfunction.Parameters = Parameters;
			myfunction.Types = Types;
			listfunctiondefinition.set(i,myfunction);
			
		}
	}		
	

	private static void CompareParametersInFunctionCallsWithParametersInFunctionDefinition(
			List<Function> listfunctionscalls,
			List<Function> listfunctiondefinition) {
		// TODO Auto-generated method stub
			Function myfunctioncalls = new Function();
		for(int i=0;i<listfunctionscalls.size();i++)
		{
				myfunctioncalls = listfunctionscalls.get(i);
				if (myfunctioncalls.FunctionNameShort != null)
					FindParametersIssues(myfunctioncalls,listfunctiondefinition);
		 
		}
		
	}

	private static void FindParametersIssues(Function myfunctioncalls,
			List<Function> listfunctiondefinition) 
	{
		// TODO Auto-generated method stub
		Function functiondef = new Function();
			for(int i=0;i<listfunctiondefinition.size();i++)
			{
				functiondef = listfunctiondefinition.get(i);
				if	((myfunctioncalls.FunctionNameShort == null) || (functiondef.FunctionNameShort == null))  
					//saveResults("*********** Error in Parameters NULLS" + myfunctioncalls.FuntionName + " " + myfunctioncalls.FileName + " and " + listfunctiondefinition.get(i).FuntionName + " in " + listfunctiondefinition.get(i).FileName,"C:\\test\\acurity\\function_calls_errorS.txt" );
				continue;
					
					//System.out.println("******** Error in Parameters " + myfunctioncalls.FunctionNameShort + " " + myfunctioncalls.FileName + " and " + listfunctiondefinition.get(i).FunctionNameShort + " in " + listfunctiondefinition.get(i).FileName );
				else
				{
				if ((myfunctioncalls.FunctionNameShort.trim().equals(functiondef.FunctionNameShort.trim())) && (!(myfunctioncalls.FileName.equals(functiondef.FileName))))
				{
					if (myfunctioncalls.Parameters.length != functiondef.Parameters.length )
						saveResults("*********** Error in Parameters numbers" + myfunctioncalls.FunctionNameShort + " " + myfunctioncalls.FileName + " and " + listfunctiondefinition.get(i).FunctionNameShort + " in " + listfunctiondefinition.get(i).FileName,"C:\\test\\acurity\\function_calls_error_numbers.txt" );
					else
					{
						for (int j=0;j<myfunctioncalls.Types.length;j++)
						{
							if (!(myfunctioncalls.Types[j].trim().toUpperCase().equals(functiondef.Types[j].trim().toUpperCase())))
								saveResults("*********** Error in Parameters types" + myfunctioncalls.FunctionNameShort + " " + myfunctioncalls.FileName + " and " + listfunctiondefinition.get(i).FunctionNameShort + " in " + listfunctiondefinition.get(i).FileName,"C:\\test\\acurity\\function_calls_error_types.txt" );
								
							
						}
							
					}
					break;
				}
			  }
			}
				
			
	}
		
	
	private static void saveResults(String line,String fullfilepath) {
		try
		{
		    String filename= fullfilepath;
		    FileWriter fw = new FileWriter(filename,true); //the true will append the new data
		    
				fw.write(line);
				fw.write("\n");
				
				    
		    fw.close();
		}
		catch(IOException ioe)
		{
		    System.err.println("IOException: " + ioe.getMessage());
		}
	}

	private static void saveResults(List<Function> listfunctions,String fullfilepath) {
		try
		{
		    String filename= fullfilepath;
		    FileWriter fw = new FileWriter(filename,true); //the true will append the new data
		    for (int i = 0; i < listfunctions.size(); i++) {
				fw.write(listfunctions.get(i).FileName + "_" + listfunctions.get(i).FuntionName + "_" + listfunctions.get(i).FunctionNameShort);
				fw.write("\n");
				
			}		    
		    fw.close();
		}
		catch(IOException ioe)
		{
		    System.err.println("IOException: " + ioe.getMessage());
		}
	}
	private static void saveVariable(List<Variable> listVariables,String fullfilepath) {
		try
		{
		    String filename= fullfilepath;
		    FileWriter fw = new FileWriter(filename,true); //the true will append the new data
		    for (int i = 0; i < listVariables.size(); i++) {
				fw.write(listVariables.get(i).FileName + "_" + listVariables.get(i).VariableName);
				fw.write("\n");
				
			}		    
		    fw.close();
		}
		catch(IOException ioe)
		{
		    System.err.println("IOException: " + ioe.getMessage());
		}
	}
	

}
