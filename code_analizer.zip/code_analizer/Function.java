public class Function implements IFunction
{
  public String FileName;
  public String FuntionName;
  public String FunctionNameShort;
  public String[] Parameters;
  public String[] Types;
}