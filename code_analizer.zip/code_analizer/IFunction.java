public interface IFunction {

}