
public class Variable implements IFunction {
	 public String FileName;
	 public String VariableName;	
	 public String[] variablelist;
	 public String variabletype;
}
