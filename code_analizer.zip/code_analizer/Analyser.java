import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


public class Analyser {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public List<String> GetLines(String fullfilepath) throws IOException
	{
		List<String> listLines = new ArrayList<String>();
		FileInputStream fis = new FileInputStream(fullfilepath);
		 
		//Construct BufferedReader from InputStreamReader
		BufferedReader br = new BufferedReader(new InputStreamReader(fis));
	 
		String line = null;
		while ((line = br.readLine()) != null) {
		//	System.out.println(line);
			listLines.add(line);
		}
	 
		br.close();

		return listLines;		
	}
	
	public void  GetFunctions(List<String> lines,List<Function> listFunctionsCalls,List<Function> listFunctionsDefinition,List<Variable> listvariables, String FileName)
	{
		List<Function> listFunctionsCallsTemp = new ArrayList<Function>();
		List<Variable> listvariablesTemp = new ArrayList<Variable>(); 
		List<Function> listfunctiondefinitionTemp = new ArrayList<Function>(); 
		String functioncall = "";
		String functiondefinition = "";
		String variabledefinition = "";
		
		for (int i = 0; i < lines.size(); i++) {
			 functioncall = CheckFunctionCall(lines.get(i).trim());
			 if (functioncall.trim().length() > 1)
			 {
				 Function functionCall = new Function();
				 functionCall.FileName = FileName;
				 functionCall.FuntionName = functioncall;
				 listFunctionsCallsTemp.add(functionCall);
			 }
			 
			 functiondefinition = CheckFunctionDefinition(lines.get(i).trim());
			 if (functiondefinition.trim().length() > 1)
			 {
				 Function functionDef = new Function();
				 functionDef.FileName = FileName;
				 functionDef.FuntionName = functiondefinition;
				 
				 listfunctiondefinitionTemp.add(functionDef);				 
			 }
			 
			 variabledefinition = CheckVariableDefinition(lines.get(i).trim());
			 if (variabledefinition.trim().length() > 1)
			 {
				 Variable variableDef = new 				 Variable();
				 variableDef.FileName = FileName;
				 variableDef.VariableName = variabledefinition;
				 
				 listvariablesTemp.add(variableDef);				 
			 }
			 
		}
		GetVariablesTypes(listvariablesTemp);
		GetVariablesAndTypesInFunctionCalls(listFunctionsCallsTemp,listvariablesTemp);
	//	GetVariablesAndTypesInFunctionDef(listfunctiondefinitionTemp,listVariableTypesFnDef)
	
		
		//return listFunctions;
		listFunctionsCalls.addAll(listFunctionsCallsTemp);
		listFunctionsDefinition.addAll(listfunctiondefinitionTemp);
		listvariables.addAll(listvariablesTemp);
	}

	

	private void GetVariablesTypes(List<Variable> listvariablesTemp) {
		// TODO Auto-generated method stub
			
		Variable variable = new Variable();
		for(int i=0;i <listvariablesTemp.size();i++){
			variable = listvariablesTemp.get(i);
			GetVariablesDefinition(variable);
			listvariablesTemp.set(i,variable);
			
		}
		
	}

	private void GetVariablesDefinition(Variable variable) {
		// TODO Auto-generated method stub
		String line = variable.VariableName.trim();
		String type = line.substring(line.indexOf(":")+1 ,line.length());
		line.replaceFirst("VAR","");
		String[] variables = line.substring(0,line.indexOf(":")).split(",");
		variable.variablelist = variables;
		variable.variabletype = type;
	}

	private void GetVariablesAndTypesInFunctionCalls(
			List<Function> listFunctionsCallsTemp,
			List<Variable> listvariablesTemp) 
	{
		
		Function function = new Function();
		// TODO Auto-generated method stub
		for (int i = 0; i < listFunctionsCallsTemp.size(); i++) {
			function = listFunctionsCallsTemp.get(i);
			GetVariables(function);
			GetVariablesTypes(function,listvariablesTemp);
			//if (results.get(i).indexOf("U8M8") > 0)
			listFunctionsCallsTemp.set(i,function);
			
			
		}
	}
private void GetVariablesTypes(Function function,List<Variable> listvariablesTemp) 
{
				String[] variables;
				String parameter;
				String type;
				Boolean found;
				function.Types = new String[function.Parameters.length];
				for(int i= 0;i< function.Parameters.length;i++)
				{
					found = false;
					parameter = function.Parameters[i];
					function.Types[i] = "";
					for(int j=0;j<listvariablesTemp.size();j++)
					{
						variables = listvariablesTemp.get(j).variablelist;
						type= listvariablesTemp.get(j).variabletype;
						for(int z=0;z<variables.length;z++)
						{
							if (parameter == variables[z])
							{
								function.Types[i] = type;
								found = true;
								break;
							}
						}
						if (found)
							break;
					} 
					
				}
		
	}

	//Get the variables names used in a function call.
	private void GetVariables(Function function) {
		// TODO Auto-generated method stub
		String functionname = "";
		String[] parameters = new String[]{};
		int numberofparameters;
		int positionFirstP;
		String functioncall="";
		functioncall = function.FuntionName;
		String parametersdefinition;
		function.Parameters = parameters;
		if (count(functioncall,")") == 1)
		{
			if (count(functioncall,"(") == 1)	
			{
				positionFirstP = functioncall.indexOf("(");
				functionname = functioncall.substring(0,positionFirstP);
				parametersdefinition = functioncall.substring(positionFirstP+1,functioncall.indexOf(")"));
				parameters= parametersdefinition.split(",");
				function.FunctionNameShort =functionname;
				function.Parameters = parameters;
				
			}
			else
			{
				//System.out.println("Error in GetVariables " + function.FuntionName + functioncall + " " );
				
			}
		}
		else
		{
			//System.out.println("Error in GetVariables" + function.FuntionName + functioncall + " " );
		}
		
			
	}
	public static int count(String str, String find) {
        int index = 0, count = 0;
        do {
                index  = str.indexOf(find, index);
                if ( index == -1 ) {
                        return count;
                }
                index += find.length();
                count++;
        } while( true );
	}
	private String CheckVariableDefinition(String line) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		int positiona = 0;
		int positionb = 0;
		int positionc = 0;
		int positiond = 0;
		int positione = 0;
		
		positiona = line.indexOf(":");
		positionc = line.indexOf("VAR");
		positiond = line.indexOf("//");
		positione = line.indexOf("?");
		if (positione != 0)
			if (positiond !=0)
					if (positionc >= 0)
							if ((positiona > positionc) && ((positiond > positiona) || (positiond < 0)))
									return line.substring(positionc);
		    
		return "";
	}

	private String CheckFunctionDefinition(String line) {
		// TODO Auto-generated method stub
		int positiona = 0;
		int positionb = 0;
		int positionc = 0;
		int positiond = 0;
		int positione = 0;
		
		positiond = line.indexOf("//");
		positione = line.indexOf("?");
		
		if (positione != 0)
			if (positiond !=0)
			{
		
		
		positiona = line.indexOf(")");
		positionb = line.indexOf("(");
		positionc = line.indexOf("FUNCTION");
		positiond = line.indexOf("//");
		if (positionc >= 0)
	    	if ((positiona > positionb) && (positionb > positionc) && ((positiond > positiona) || (positiond < 0)))
		    
	    		return line.substring(positionc);
		    
			}
		return "";
	}

	private String CheckFunctionCall(String line) {
		// TODO Auto-generated method stub
		int positiona = 0;
		int positionb = 0;
		int positionc = 0;
		int positiond = 0;
		int positione = 0;
		
		positiona = line.indexOf(")");
		positionb = line.indexOf("(");
		positionc = line.indexOf("=");
		positiond = line.indexOf("//");
		positione = line.indexOf("?");
		
		if (positione != 0)
			if (positiond !=0)
					if (positionc > 0)
							if ((positiona > positionb) && (positionb > positionc) && ((positiond > positiona) || (positiond < 0)))
								return line.substring(positionc+1);
		    
		return "";
	}
	
}


